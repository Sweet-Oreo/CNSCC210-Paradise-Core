package com.mygdx.maps;

import com.badlogic.gdx.scenes.scene2d.Stage;
import com.mygdx.bases.BaseActor;

public class End3 extends BaseActor
{
    public End3(float x, float y, Stage s)
    {
        super(x, y, s);
        loadTexture("items/End.png");
    }
}
